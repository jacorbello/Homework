# Introduction
This is a shell implementation, written in C, used to interpret command line input from a user and execute.

## Running the program
On a linux machine:
- Copy the files to a single directory
- Compile the program
    - ```gcc -o program project.c minishell.h```
- Run the program
    - ```./program```

